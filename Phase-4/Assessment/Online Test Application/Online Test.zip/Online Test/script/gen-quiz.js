let quiz=[
    {
        question:"Inaccuracy in computer data is called?",
        option:[
            "1.Chip",
            "2.Byte",
            "3.Bit",
            "4.Bug",
        ],
        answer:4,
    },
    {
        question:"Which type of lens is used in camera?",
        option:[
            "1.Convex",
            "2.Concave",
            "3.Circular",
            "4.Equal thickness",
            
        ],
        answer:1,
    },
    {
        question:"How many Indian states have Hindi as their language?",
        option:[
            "1.16",
            "2.12",
            "3.15",
            "4.10",   
        ],
        answer:4,
    },
    {
        question:"What is the name of the first spacecraft that reached Mars?",
        option:[
            "1.Viking",
            "2.Apollo 12",
            "3.Sputnik",
            "4.GSL-V-S",   
        ],
        answer:1,

    },
    {
        question:"What is the full form of LAN",
        option:[
            "1.Lane Area Network",
            "2.Local Area Network",
            "3.Large Area Network",
            "4.None of These",   
        ],
        answer:2,
    }
]