let quiz=[
    {
        question:"Which is the largest state in India?",
        option:[
            "1.Madhya Pradesh",
            "2.Rajasthan",
            "3.Uttar Pradesh",
            "4.Maharashtra",
        ],
        answer:2,
    },
    {
        question:"How many countries are there in Australlian Continent?",
        option:[
            "1.24",
            "2.12",
            "3.2",
            "4.4",
            
        ],
        answer:4,
    },
    {
        question:"Victoria Falls are on which river?",
        option:[
            "1.Niger",
            "2.Congo",
            "3.Zambezi",
            "4.Orange",   
        ],
        answer:3,
    },
    {
        question:"Which is the longest river in India?",
        option:[
            "1.Ganga",
            "2.Yamuna",
            "3.Narmada",
            "4.None of These",   
        ],
        answer:1,

    },
    {
        question:"Which is the world's largest Island?",
        option:[
            "1.New Guinea",
            "2.Greenland",
            "3.Madagascar",
            "4.Iceland",   
        ],
        answer:2,
    }
]