let quiz=[
    {
        question:"When did the capital of India shift from Calcutta to New Delhi?",
        option:[
            "1.1910",
            "2.1911",
            "3.1912",
            "4.1914",
        ],
        answer:2,
    },
    {
        question:"In which year Quit India Movement started?",
        option:[
            "1.1940",
            "2.1942",
            "3.1943",
            "4.1945",
            
        ],
        answer:1,
    },
    {
        question:"Who is the 1st citizen of India?",
        option:[
            "1.President",
            "2.Vice-President",
            "3.Prime Minister",
            "4.Former President",   
        ],
        answer:1,
    },
    {
        question:"In which year, Nadirshah invade India and sacked Delhi?",
        option:[
            "1.1735",
            "2.1739",
            "3.1740",
            "4.1751",   
        ],
        answer:2,

    },
    {
        question:"When did 1st World War started?",
        option:[
            "1.1912",
            "2.1913",
            "3.1914",
            "4.1915",   
        ],
        answer:2,
    }
]